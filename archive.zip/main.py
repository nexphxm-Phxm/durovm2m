import asyncio
import logging
import re
import sys
import datetime
import random
import time

# ======================= DEPENDENCY CHECK =======================
try:
    from telethon import TelegramClient, events, Button
    from telethon.sessions import StringSession
    from telethon.errors import (
        SessionPasswordNeededError,
        PhoneCodeInvalidError,
        PasswordHashInvalidError,
        FloodWaitError,
        UserAlreadyParticipantError,
        InviteRequestSentError,
        ChannelPrivateError,
        ChatAdminRequiredError,
        UserNotParticipantError,
        InviteHashInvalidError,
        InviteHashExpiredError
    )
    from telethon.tl.functions.messages import ImportChatInviteRequest
    from telethon.tl.functions.channels import JoinChannelRequest, LeaveChannelRequest
    from telethon.tl.functions.account import UpdateStatusRequest
    from telethon.tl.functions.phone import JoinGroupCallRequest, LeaveGroupCallRequest, EditGroupCallParticipantRequest
    from telethon.tl.functions.messages import GetMessagesViewsRequest
    from telethon.tl.types import Channel, Chat, InputPeerChannel, InputGroupCall
except ImportError as e:
    print(f"❌ CRITICAL ERROR: Missing dependencies! Detail: {e}")
    print("ℹ️  Please install required packages: telethon, aiofiles")
    sys.exit(1)

# ======================= CONFIGURATION IMPORT =======================
try:
    from config import API_ID, API_HASH, BOT_TOKEN, ADMIN_IDS, WELCOME_IMAGE
except ImportError:
    print("❌ CRITICAL ERROR: 'config.py' file missing!")
    sys.exit(1)

# ======================= DATABASE LAYER =======================
from database import (
    load_sessions, add_session, delete_session,
    refresh_admin_cache, get_admin_cache, add_admin_db, remove_admin_db,
    add_history, get_recent_history
)

# ================================================================

# Logging Setup
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Global State 
active_clients = {}  # {phone: Client}
task_states = {}     # {chat_id: {type, step, data...}}
vc_clients = {}      # {phone: (client, call_id)} Active VC participants
vc_call_info = {}    # {phone: call_info} Store call info for each account

# ======================= HELPER FUNCTIONS =======================

def is_user_admin(user_id):
    """Check if user is either a Config Root Admin or a DB Admin"""
    return (user_id in ADMIN_IDS) or (user_id in get_admin_cache())

def parse_join_target(link: str):
    link = link.strip()
    username_match = re.search(r"(?:t\.me/|@)([a-zA-Z0-9_]{5,32})", link)
    if username_match and "joinchat" not in link and "+" not in link:
        return ("public", username_match.group(1))
    
    invite_match = re.search(r"t\.me/(?:\+|joinchat/)([a-zA-Z0-9_-]+)", link)
    if invite_match:
        return ("private", invite_match.group(1))
    return (None, None)

def parse_vc_link(link: str):
    """Parse voice chat link - supports both public and private invites"""
    link = link.strip()
    
    # Remove any extra text before the link
    if "t.me/" in link:
        # Extract the actual link part
        match = re.search(r'(?:https?://)?(?:t\.me/)([^\s]+)', link)
        if match:
            link = f"t.me/{match.group(1)}"
    
    # Check for private invite link (has + or joinchat)
    invite_match = re.search(r"t\.me/(?:\+|joinchat/)([a-zA-Z0-9_-]+)", link)
    if invite_match:
        return ("private", invite_match.group(1))
    
    # Check for public username
    username_match = re.search(r"(?:t\.me/|@)([a-zA-Z0-9_]{5,32})", link)
    if username_match:
        return ("public", username_match.group(1))
    
    return (None, None)

async def get_channel_entity(client, channel_input):
    """Get channel entity from username or invite link - FIXED"""
    try:
        # Try to get as public channel first
        return await client.get_entity(channel_input)
    except Exception:
        # If it's a private invite link, try to join first
        link_type, target = parse_vc_link(channel_input)
        if link_type == "private":
            try:
                # Try to join the private channel first
                result = await client(ImportChatInviteRequest(target))
                
                # Handle different response types
                if hasattr(result, 'chats') and result.chats:
                    return await client.get_entity(result.chats[0].id)
                elif hasattr(result, 'chat') and result.chat:
                    return await client.get_entity(result.chat.id)
                else:
                    # If we can't get the chat from result, try to find it from updates
                    # The channel should be in the user's dialogs now
                    async for dialog in client.iter_dialogs():
                        if dialog.is_channel:
                            # Check if this is the channel we just joined
                            # Try to get the channel info
                            try:
                                channel_info = await client.get_entity(dialog.entity)
                                if channel_info:
                                    return channel_info
                            except:
                                pass
                    
                    # If still not found, try to get using the invite hash
                    # Sometimes the channel is in the update state
                    try:
                        # Get all channels the user is in
                        async for dialog in client.iter_dialogs():
                            if dialog.is_channel and dialog.entity:
                                return dialog.entity
                    except:
                        pass
                    
                    raise Exception("Could not find the channel after joining")
                    
            except UserAlreadyParticipantError:
                # Already a member, try to get entity using the link
                try:
                    # Try to get entity from the link directly
                    return await client.get_entity(channel_input)
                except:
                    # Try to find from dialogs
                    async for dialog in client.iter_dialogs():
                        if dialog.is_channel:
                            return dialog.entity
                    raise Exception("Already in channel but couldn't find it")
                    
            except Exception as e:
                raise Exception(f"Failed to join private channel: {str(e)}")
        raise Exception("Invalid channel or unable to join")

async def start_saved_clients():
    sessions = await load_sessions()
    logger.info(f"🔄 Found {len(sessions)} sessions in sessions.json. Connecting...")
    count = 0
    for phone, session_str in sessions.items():
        try:
            client = TelegramClient(StringSession(session_str), API_ID, API_HASH)
            await client.connect()
            if await client.is_user_authorized():
                active_clients[phone] = client
                count += 1
                asyncio.create_task(keep_online(client))
            else:
                logger.warning(f"⚠️ Session for {phone} is expired/invalid.")
        except Exception as e:
            logger.error(f"❌ Failed to connect {phone}: {e}")
    logger.info(f"✅ Successfully connected {count} accounts.")

async def keep_online(client):
    """Basic keepalive to prevent session kill"""
    while True:
        try:
            await client.get_me() 
            await asyncio.sleep(600)
        except Exception:
            break

async def maintain_online_status(client, duration_sec=3600):
    """Forces status to 'Online' periodically for a set duration"""
    end_time = time.time() + duration_sec
    while time.time() < end_time:
        try:
            await client(UpdateStatusRequest(offline=False))
            await asyncio.sleep(180) 
        except Exception as e:
            logger.error(f"Force Online Error: {e}")
            break

async def join_voice_chat(client, channel_entity, delay=2):
    """Join a voice chat in a channel - FIXED"""
    try:
        # Try to join the voice chat directly
        try:
            result = await client(JoinGroupCallRequest(
                peer=channel_entity,
                join_as=None,  # Use self
                muted=True,    # Join muted by default
                video_stopped=True
            ))
            await asyncio.sleep(delay)
            return True, "Successfully joined VC", None
        except Exception as e:
            error_str = str(e).lower()
            if "already" in error_str or "participant" in error_str:
                return True, "Already in VC", None
            elif "call" in error_str and ("no" in error_str or "not" in error_str):
                return False, "No active voice chat found", None
            return False, f"VC join error: {str(e)[:50]}", None
    except Exception as e:
        error_str = str(e).lower()
        if "already" in error_str:
            return True, "Already in VC", None
        return False, f"Error: {str(e)[:50]}", None

async def leave_voice_chat(client, call_id, delay=2):
    """Leave a voice chat"""
    try:
        if call_id:
            await client(LeaveGroupCallRequest(
                call=call_id,
                source=0
            ))
        else:
            # Try to leave without call_id
            await client(LeaveGroupCallRequest(
                call=InputGroupCall(
                    id=0,
                    access_hash=0
                ),
                source=0
            ))
        await asyncio.sleep(delay)
        return True, "Left VC"
    except Exception as e:
        return False, f"Error: {str(e)[:50]}"

async def add_post_views(client, channel_entity, message_id, amount=1000):
    """Add views to a specific post"""
    try:
        # We'll increment multiple times to get the desired amount
        # Since each call adds 1 view, we need to loop
        views_added = 0
        max_per_batch = min(amount, 50)  # Limit to 50 per account to avoid flood
        
        for _ in range(max_per_batch):
            try:
                await client(GetMessagesViewsRequest(
                    peer=channel_entity,
                    id=[message_id],
                    increment=True
                ))
                views_added += 1
                await asyncio.sleep(0.3)  # Small delay between views
            except FloodWaitError as e:
                await asyncio.sleep(e.seconds)
                break
            except Exception:
                break
        
        return True, f"Added {views_added} views"
    except Exception as e:
        return False, f"Error: {str(e)[:50]}"

# ======================= UI / KEYBOARDS =======================

bot = TelegramClient('bot_session', API_ID, API_HASH)

def get_header():
    return (
        f"🛡️ ** Auto Bot Manager **\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 **Active Sessions:** `{len(active_clients)}`\n"
        f"📡 **Storage:** `JSON Files`\n"
        f"👮 **Admins:** `{len(ADMIN_IDS) + len(get_admin_cache())}`\n"
        f"📞 **VC Active:** `{len(vc_clients)}`\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
    )

def main_menu_keyboard():
    return [
        [Button.inline("➕ Add New Account", b"menu_add_acc")],
        [Button.inline("🚀 Joiner Mode", b"menu_join"), Button.inline("🔥 Leaver Mode", b"menu_leave")],
        [Button.inline("🎵 VC Tools", b"menu_vc"), Button.inline("👁️ Post Views", b"menu_views")],
        [Button.inline("📋 List Accounts", b"list_accs"), Button.inline("📜 Activity Log", b"show_history")],
        [Button.inline("👮 Manage Admins", b"menu_admins"), Button.inline("⚙️ Delete Accs", b"menu_manage")]
    ]

def vc_menu_keyboard():
    return [
        [Button.inline("🎵 Join Voice Chat", b"vc_join"), Button.inline("🚪 Leave Voice Chat", b"vc_leave")],
        [Button.inline("📊 Active VC List", b"vc_list")],
        [Button.inline("🔙 Back to Main Menu", b"cancel")]
    ]

def views_menu_keyboard():
    return [
        [Button.inline("👁️ Add Post Views", b"views_add")],
        [Button.inline("🔙 Back to Main Menu", b"cancel")]
    ]

def admin_menu_keyboard():
    return [
        [Button.inline("➕ Add Admin", b"add_admin_start"), Button.inline("➖ Remove Admin", b"rem_admin_start")],
        [Button.inline("📋 List DB Admins", b"list_db_admins")],
        [Button.inline("🔙 Back to Main Menu", b"cancel")]
    ]

def add_account_keyboard():
    return [
        [Button.inline("📱 Login via Phone Number", b"add_phone")],
        [Button.inline("🧵 Login via String Session", b"add_string")],
        [Button.inline("🔙 Back to Main Menu", b"cancel")]
    ]

def join_menu_keyboard():
    return [
        [Button.inline("🎯 Start Join Task", b"start_join")],
        [Button.inline("🔙 Back to Main Menu", b"cancel")]
    ]

def leave_menu_keyboard():
    return [
        [Button.inline("📤 Leave Specific Channel", b"leave_specific")],
        [Button.inline("☢️ Leave ALL (Mass Clean)", b"leave_all_confirm")],
        [Button.inline("🔙 Back to Main Menu", b"cancel")]
    ]

def quantity_keyboard():
    return [
        [Button.inline("10 Accounts", b"qty_10"), Button.inline("50 Accounts", b"qty_50")],
        [Button.inline("100 Accounts", b"qty_100"), Button.inline("♾️ All Accounts", b"qty_all")],
        [Button.inline("🔢 Custom Amount", b"qty_custom")],
        [Button.inline("🔙 Cancel", b"cancel")]
    ]

def vc_quantity_keyboard():
    return [
        [Button.inline("5 Accounts", b"vc_qty_5"), Button.inline("10 Accounts", b"vc_qty_10")],
        [Button.inline("20 Accounts", b"vc_qty_20"), Button.inline("♾️ All Accounts", b"vc_qty_all")],
        [Button.inline("🔢 Custom Amount", b"vc_qty_custom")],
        [Button.inline("🔙 Cancel", b"cancel")]
    ]

def views_quantity_keyboard():
    return [
        [Button.inline("100 Views", b"views_100"), Button.inline("500 Views", b"views_500")],
        [Button.inline("1000 Views", b"views_1000"), Button.inline("5000 Views", b"views_5000")],
        [Button.inline("🔢 Custom Amount", b"views_custom")],
        [Button.inline("🔙 Cancel", b"cancel")]
    ]

def confirm_leave_all_keyboard():
    return [
        [Button.inline("✅ YES, NUKE IT", b"exec_leave_all")],
        [Button.inline("❌ NO, CANCEL", b"cancel")]
    ]

def cancel_keyboard():
    return [[Button.inline("🔙 Cancel / Back", b"cancel")]]

# ======================= LOGIC EXECUTORS =======================

async def execute_join_task(event, task_data, count_limit):
    link_type = task_data['link_type']
    target = task_data['target']
    delay = task_data['delay']
    display_link = task_data['display_link']

    all_phones = list(active_clients.keys())
    selected_phones = all_phones[:count_limit]

    # FORCE ONLINE: Start background tasks
    for phone in selected_phones:
        client = active_clients[phone]
        asyncio.create_task(maintain_online_status(client, duration_sec=3600))

    msg_text = (
        f"🚀 **Starting Join Task**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎯 **Target:** `{display_link}`\n"
        f"👥 **Accounts:** `{len(selected_phones)}`\n"
        f"⏱ **Delay:** `{delay}s`\n"
        f"🟢 **Status:** `Force Online (1h) Enabled`\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    status_msg = await event.respond(msg_text)
    
    success = 0
    failed = 0
    
    for i, phone in enumerate(selected_phones):
        client = active_clients[phone]
        status_log = "Unknown"
        
        try:
            if link_type == 'public':
                await client(JoinChannelRequest(target))
                status_log = "Joined Public"
            else:
                await client(ImportChatInviteRequest(target))
                status_log = "Joined Private"
            success += 1
        except UserAlreadyParticipantError:
            status_log = "Already Joined"
            success += 1 
        except InviteRequestSentError:
            status_log = "Request Sent"
            success += 1 
        except FloodWaitError as e:
            status_log = f"FloodWait {e.seconds}s"
            failed += 1
        except Exception as e:
            status_log = f"Error: {e}"
            failed += 1
        
        add_history(f"[{datetime.datetime.now().strftime('%H:%M')}] {phone} – {status_log} @ {display_link}")

        # Update UI every 5 accounts
        if (i + 1) % 5 == 0 or (i + 1) == len(selected_phones):
            progress_bar = "▓" * int((i+1)/len(selected_phones)*10) + "░" * (10 - int((i+1)/len(selected_phones)*10))
            await status_msg.edit(
                f"🔄 **Processing Task...**\n`[{progress_bar}]` {int(((i+1)/len(selected_phones))*100)}%\n\n"
                f"✅ Success: `{success}`\n❌ Failed: `{failed}`\n"
                f"🟢 Accounts are being forced Online."
            )
        
        await asyncio.sleep(delay)

    await status_msg.edit(
        f"🏁 **Task Completed Successfully!**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎯 Target: `{display_link}`\n"
        f"✅ **Total Success:** `{success}`\n"
        f"❌ **Total Failed:** `{failed}`\n"
        f"🟢 **Online Status:** Active for ~1h\n"
        f"━━━━━━━━━━━━━━━━━━",
        buttons=main_menu_keyboard()
    )

async def execute_leave_specific(event, link, delay=2):
    link_type, target = parse_join_target(link)
    if not link_type:
        return await event.respond("❌ **Invalid Link Format!**")

    status_msg = await event.respond(f"📤 **Leaving Channel: {link}...**")
    left_count = 0
    
    for phone, client in active_clients.items():
        try:
            if link_type == 'public':
                await client(LeaveChannelRequest(target))
            else:
                entity = await client.get_entity(link)
                await client.delete_dialog(entity)
            left_count += 1
            add_history(f"[{datetime.datetime.now().strftime('%H:%M')}] {phone} – Left {link}")
        except Exception as e:
            logger.error(f"Leave error {phone}: {e}")
        
        await asyncio.sleep(delay)
        
    await status_msg.edit(f"✅ **Execution Finished.**\nLeft from `{left_count}` accounts.", buttons=main_menu_keyboard())

async def execute_leave_all_channels(event):
    status_msg = await event.respond("☢️ **INITIATING MASS LEAVE PROTOCOL...**\nPlease wait, this may take time.")
    
    total_left = 0
    for phone, client in active_clients.items():
        try:
            async for dialog in client.iter_dialogs():
                if dialog.is_channel or dialog.is_group:
                    try:
                        await client.delete_dialog(dialog.entity)
                        total_left += 1
                        await asyncio.sleep(0.5)
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Error on {phone}: {e}")
            
    await status_msg.edit(f"✅ **Mass Leave Completed.**\nTotal chats removed: `{total_left}`", buttons=main_menu_keyboard())

async def execute_vc_join_task(event, channel_input, count_limit, delay=2):
    """Execute voice chat join task - supports private channels - FIXED"""
    all_phones = list(active_clients.keys())
    selected_phones = all_phones[:count_limit]
    
    if not selected_phones:
        await event.respond("❌ No accounts available!")
        return
    
    msg_text = (
        f"🎵 **Starting VC Join Task**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎯 **Channel:** `{channel_input}`\n"
        f"👥 **Accounts:** `{len(selected_phones)}`\n"
        f"⏱ **Delay:** `{delay}s`\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    status_msg = await event.respond(msg_text)
    
    success = 0
    failed = 0
    channel_entity = None
    channel_name = channel_input
    
    # Get channel entity using first account
    try:
        first_client = active_clients[selected_phones[0]]
        channel_entity = await get_channel_entity(first_client, channel_input)
        
        if not channel_entity:
            raise Exception("Could not get channel entity")
            
        channel_name = channel_entity.title if hasattr(channel_entity, 'title') else channel_input
        await status_msg.edit(
            f"✅ **Channel Found!**\n"
            f"📢 Name: `{channel_name}`\n"
            f"🔄 Starting VC join process...\n"
        )
    except Exception as e:
        await status_msg.edit(f"❌ Failed to get channel: {str(e)}")
        return
    
    for i, phone in enumerate(selected_phones):
        client = active_clients[phone]
        status_log = "Unknown"
        
        try:
            # Force online
            asyncio.create_task(maintain_online_status(client, duration_sec=1800))
            
            # Make sure account is in the channel
            try:
                # Try to get participants to check membership
                await client.get_participants(channel_entity, limit=1)
            except UserNotParticipantError:
                # Not a member, try to join
                try:
                    # Try joining with invite if private
                    link_type, target = parse_vc_link(channel_input)
                    if link_type == "private":
                        await client(ImportChatInviteRequest(target))
                    else:
                        if hasattr(channel_entity, 'username') and channel_entity.username:
                            await client(JoinChannelRequest(channel_entity.username))
                        else:
                            await client(JoinChannelRequest(channel_entity))
                    await asyncio.sleep(1)
                    
                    # Refresh channel entity for this client
                    channel_entity = await client.get_entity(channel_entity)
                    
                except UserAlreadyParticipantError:
                    # Already in channel, continue
                    pass
                except Exception as join_err:
                    status_log = f"Join failed: {str(join_err)[:30]}"
                    failed += 1
                    add_history(f"[{datetime.datetime.now().strftime('%H:%M')}] {phone} – VC {status_log}")
                    continue
            
            # Now join the voice chat
            try:
                success_flag, msg, call_id = await join_voice_chat(client, channel_entity, delay)
                if success_flag:
                    success += 1
                    status_log = "Joined VC"
                    if call_id:
                        vc_clients[phone] = (client, call_id)
                    else:
                        # Store without call_id
                        vc_clients[phone] = (client, None)
                else:
                    failed += 1
                    status_log = msg
                    
            except Exception as e:
                status_log = f"VC join error: {str(e)[:30]}"
                failed += 1
                
        except FloodWaitError as e:
            status_log = f"FloodWait {e.seconds}s"
            failed += 1
        except Exception as e:
            status_log = f"Error: {str(e)[:50]}"
            failed += 1
        
        add_history(f"[{datetime.datetime.now().strftime('%H:%M')}] {phone} – VC {status_log}")
        
        # Update UI every 3 accounts
        if (i + 1) % 3 == 0 or (i + 1) == len(selected_phones):
            progress_bar = "▓" * int((i+1)/len(selected_phones)*10) + "░" * (10 - int((i+1)/len(selected_phones)*10))
            await status_msg.edit(
                f"🔄 **Processing VC Join...**\n`[{progress_bar}]` {int(((i+1)/len(selected_phones))*100)}%\n\n"
                f"✅ Success: `{success}`\n❌ Failed: `{failed}`\n"
                f"🎯 Channel: `{channel_name}`\n"
                f"🟢 Online status active for 30min"
            )
        
        await asyncio.sleep(delay)
    
    await status_msg.edit(
        f"🏁 **VC Join Task Completed!**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"🎯 Channel: `{channel_name}`\n"
        f"✅ **Successfully Joined VC:** `{success}`\n"
        f"❌ **Failed:** `{failed}`\n"
        f"📞 **Active VC:** `{len(vc_clients)}`\n"
        f"🟢 **Online Status:** Active for 30min\n"
        f"━━━━━━━━━━━━━━━━━━",
        buttons=main_menu_keyboard()
    )

async def execute_vc_leave_task(event, count_limit, delay=2):
    """Execute voice chat leave task for all active VC participants"""
    if not vc_clients:
        await event.respond("❌ No active VC connections found!")
        return
    
    selected_phones = list(vc_clients.keys())[:count_limit]
    
    msg_text = (
        f"🚪 **Starting VC Leave Task**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"👥 **Accounts:** `{len(selected_phones)}`\n"
        f"⏱ **Delay:** `{delay}s`\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    status_msg = await event.respond(msg_text)
    
    success = 0
    failed = 0
    
    for i, phone in enumerate(selected_phones):
        client, call_id = vc_clients[phone]
        status_log = "Unknown"
        
        try:
            success_flag, msg = await leave_voice_chat(client, call_id, delay)
            if success_flag:
                success += 1
                status_log = "Left VC"
                del vc_clients[phone]
            else:
                failed += 1
                status_log = msg
                
        except Exception as e:
            status_log = f"Error: {str(e)[:50]}"
            failed += 1
            try:
                del vc_clients[phone]
            except KeyError:
                pass
        
        add_history(f"[{datetime.datetime.now().strftime('%H:%M')}] {phone} – VC Leave: {status_log}")
        
        # Update UI every 3 accounts
        if (i + 1) % 3 == 0 or (i + 1) == len(selected_phones):
            progress_bar = "▓" * int((i+1)/len(selected_phones)*10) + "░" * (10 - int((i+1)/len(selected_phones)*10))
            await status_msg.edit(
                f"🔄 **Processing VC Leave...**\n`[{progress_bar}]` {int(((i+1)/len(selected_phones))*100)}%\n\n"
                f"✅ Left: `{success}`\n❌ Failed: `{failed}`"
            )
        
        await asyncio.sleep(delay)
    
    await status_msg.edit(
        f"🏁 **VC Leave Task Completed!**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"✅ **Successfully Left VC:** `{success}`\n"
        f"❌ **Failed:** `{failed}`\n"
        f"📞 **Remaining VC:** `{len(vc_clients)}`\n"
        f"━━━━━━━━━━━━━━━━━━",
        buttons=main_menu_keyboard()
    )

async def execute_post_views_task(event, channel_input, message_id, views_amount, count_limit):
    """Execute post views adding task"""
    all_phones = list(active_clients.keys())
    selected_phones = all_phones[:count_limit]
    
    if not selected_phones:
        await event.respond("❌ No accounts available!")
        return
    
    msg_text = (
        f"👁️ **Starting Post Views Task**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📢 **Channel:** `{channel_input}`\n"
        f"📝 **Post ID:** `{message_id}`\n"
        f"👀 **Views Target:** `{views_amount}`\n"
        f"👥 **Accounts:** `{len(selected_phones)}`\n"
        f"━━━━━━━━━━━━━━━━━━"
    )
    status_msg = await event.respond(msg_text)
    
    # Get channel entity
    try:
        first_client = active_clients[selected_phones[0]]
        channel_entity = await get_channel_entity(first_client, channel_input)
        channel_name = channel_entity.title if channel_entity else channel_input
    except Exception as e:
        await status_msg.edit(f"❌ Failed to get channel: {e}")
        return
    
    total_views_added = 0
    success_accounts = 0
    failed_accounts = 0
    
    for i, phone in enumerate(selected_phones):
        client = active_clients[phone]
        status_log = "Unknown"
        
        try:
            # Force online
            asyncio.create_task(maintain_online_status(client, duration_sec=1800))
            
            # Make sure account is in the channel
            try:
                await client.get_participants(channel_entity, limit=1)
            except UserNotParticipantError:
                try:
                    link_type, target = parse_vc_link(channel_input)
                    if link_type == "private":
                        await client(ImportChatInviteRequest(target))
                    else:
                        if hasattr(channel_entity, 'username') and channel_entity.username:
                            await client(JoinChannelRequest(channel_entity.username))
                        else:
                            await client(JoinChannelRequest(channel_entity))
                    await asyncio.sleep(1)
                except Exception:
                    pass
            
            success_flag, msg = await add_post_views(client, channel_entity, message_id, views_amount)
            if success_flag:
                success_accounts += 1
                # Parse views added from message
                views_match = re.search(r'Added (\d+) views', msg)
                if views_match:
                    added = int(views_match.group(1))
                    total_views_added += added
                status_log = msg
            else:
                failed_accounts += 1
                status_log = msg
                
        except FloodWaitError as e:
            status_log = f"FloodWait {e.seconds}s"
            failed_accounts += 1
        except Exception as e:
            status_log = f"Error: {str(e)[:50]}"
            failed_accounts += 1
        
        add_history(f"[{datetime.datetime.now().strftime('%H:%M')}] {phone} – Views: {status_log}")
        
        # Update UI every 3 accounts
        if (i + 1) % 3 == 0 or (i + 1) == len(selected_phones):
            progress_bar = "▓" * int((i+1)/len(selected_phones)*10) + "░" * (10 - int((i+1)/len(selected_phones)*10))
            await status_msg.edit(
                f"🔄 **Adding Post Views...**\n`[{progress_bar}]` {int(((i+1)/len(selected_phones))*100)}%\n\n"
                f"✅ Successful Accounts: `{success_accounts}`\n"
                f"❌ Failed Accounts: `{failed_accounts}`\n"
                f"👀 Total Views Added: `{total_views_added}`"
            )
        
        await asyncio.sleep(1)  # Small delay between accounts
    
    await status_msg.edit(
        f"🏁 **Post Views Task Completed!**\n"
        f"━━━━━━━━━━━━━━━━━━\n"
        f"📢 Channel: `{channel_name}`\n"
        f"📝 Post ID: `{message_id}`\n"
        f"👀 **Total Views Added:** `{total_views_added}`\n"
        f"✅ **Successful Accounts:** `{success_accounts}`\n"
        f"❌ **Failed Accounts:** `{failed_accounts}`\n"
        f"━━━━━━━━━━━━━━━━━━",
        buttons=main_menu_keyboard()
    )

# ======================= HANDLERS =======================

@bot.on(events.NewMessage(pattern='/start'))
async def start_handler(event):
    if not is_user_admin(event.sender_id):
        return await event.respond("⛔ **Access Denied.** You are not authorized.")
    
    caption_text = get_header() + "👇 **Select an option below:**"

    if WELCOME_IMAGE:
        try:
            await event.respond(
                message=caption_text,
                file=WELCOME_IMAGE,
                buttons=main_menu_keyboard()
            )
        except Exception as e:
            logger.error(f"Failed to send welcome image: {e}")
            await event.respond(caption_text, buttons=main_menu_keyboard())
    else:
        await event.respond(caption_text, buttons=main_menu_keyboard())

@bot.on(events.CallbackQuery)
async def callback_handler(event):
    if not is_user_admin(event.sender_id): return
    
    data = event.data.decode('utf-8')
    chat_id = event.chat_id

    if data == "cancel":
        if chat_id in task_states: del task_states[chat_id]
        await event.edit(get_header() + "👇 **Main Menu:**", buttons=main_menu_keyboard())
    
    elif data == "menu_admins":
        await event.edit(
            "👮 **Admin Management**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Manage who can access this bot.\n"
            "Note: Admins in `config.py` cannot be removed here.",
            buttons=admin_menu_keyboard()
        )
    
    elif data == "add_admin_start":
        task_states[chat_id] = {'type': 'add_admin', 'step': 'ask_id'}
        await event.edit("👮 **Add Admin**\n\nSend the **Numeric Telegram ID** of the user to promote:", buttons=cancel_keyboard())
    
    elif data == "rem_admin_start":
        db_admins = get_admin_cache()
        if not db_admins:
            await event.answer("No DB admins to remove!", alert=True)
            return
        
        buttons = []
        for uid in db_admins:
            buttons.append([Button.inline(f"🗑 Remove {uid}", f"rem_adm_{uid}")])
        buttons.append([Button.inline("🔙 Back", b"menu_admins")])
        
        await event.edit("👮 **Remove Admin**\n\nSelect a user to demote:", buttons=buttons)

    elif data == "list_db_admins":
        db_admins = get_admin_cache()
        if not db_admins:
            msg = "No admins in Database."
        else:
            msg = "\n".join([f"👤 `{uid}`" for uid in db_admins])
        
        cfg_msg = "\n".join([f"👑 `{uid}`" for uid in ADMIN_IDS]) if ADMIN_IDS else "None"
        
        await event.edit(f"👮 **Admin List**\n\n**Config Admins:**\n{cfg_msg}\n\n**Database Admins:**\n{msg}", buttons=[[Button.inline("🔙 Back", b"menu_admins")]])

    elif data.startswith("rem_adm_"):
        target_id = int(data.split("_")[2])
        if await remove_admin_db(target_id):
            await event.answer("Admin Removed!", alert=True)
            # Refresh list
            db_admins = get_admin_cache()
            if not db_admins:
                await event.edit("✅ Admin removed. No DB admins left.", buttons=admin_menu_keyboard())
            else:
                buttons = [[Button.inline(f"🗑 Remove {uid}", f"rem_adm_{uid}")] for uid in db_admins]
                buttons.append([Button.inline("🔙 Back", b"menu_admins")])
                await event.edit("✅ Removed. Select another?", buttons=buttons)
        else:
            await event.answer("Failed to remove.", alert=True)

    elif data == "menu_add_acc":
        await event.edit(
            "➕ **Add New Account**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Choose your preferred login method:",
            buttons=add_account_keyboard()
        )

    elif data == "menu_join":
        await event.edit(
            "🚀 **Joiner Control**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Boost channels or groups with your accounts.",
            buttons=join_menu_keyboard()
        )

    elif data == "menu_leave":
        await event.edit(
            "🔥 **Leaver Control**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Manage account subscriptions.",
            buttons=leave_menu_keyboard()
        )
    
    elif data == "menu_vc":
        await event.edit(
            "🎵 **Voice Chat Tools**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Join or leave voice chats with your accounts.\n"
            f"📞 **Active VC Connections:** `{len(vc_clients)}`\n\n"
            "• Public: `@channel_username` or `t.me/channel`\n"
            "• Private: `t.me/+invite_code` or `t.me/joinchat/...`",
            buttons=vc_menu_keyboard()
        )
    
    elif data == "menu_views":
        await event.edit(
            "👁️ **Post Views Booster**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Add views to posts on your channels/groups.\n"
            "Works best with multiple accounts.",
            buttons=views_menu_keyboard()
        )
    
    elif data == "vc_join":
        if not active_clients: 
            return await event.answer("❌ No accounts loaded!", alert=True)
        task_states[chat_id] = {'type': 'vc_join', 'step': 'ask_channel'}
        await event.edit(
            "🎵 **Join Voice Chat**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Send the channel link or invite link:\n\n"
            "• Public: `@channel_username` or `t.me/channel`\n"
            "• Private: `t.me/+invite_code` or `t.me/joinchat/...`\n"
            "━━━━━━━━━━━━━━━━━━",
            buttons=cancel_keyboard()
        )
    
    elif data == "vc_leave":
        if not vc_clients:
            return await event.answer("❌ No active VC connections!", alert=True)
        task_states[chat_id] = {'type': 'vc_leave', 'step': 'ask_quantity'}
        await event.edit("🚪 **Leave Voice Chat**\n\nHow many accounts should leave VC?", buttons=vc_quantity_keyboard())
    
    elif data == "vc_list":
        if not vc_clients:
            msg = "❌ No active VC connections."
        else:
            msg = "\n".join([f"👤 `{phone}`" for phone in vc_clients.keys()])
        
        await event.edit(
            f"📊 **Active VC Participants**\n"
            f"━━━━━━━━━━━━━━━━━━\n"
            f"{msg}\n\n"
            f"📞 **Total:** `{len(vc_clients)}`",
            buttons=[[Button.inline("🔙 Back", b"menu_vc")]]
        )
    
    elif data == "views_add":
        if not active_clients:
            return await event.answer("❌ No accounts loaded!", alert=True)
        task_states[chat_id] = {'type': 'views_add', 'step': 'ask_channel'}
        await event.edit(
            "👁️ **Add Post Views**\n"
            "━━━━━━━━━━━━━━━━━━\n"
            "Send the channel link or invite link:\n\n"
            "• Public: `@channel_username` or `t.me/channel`\n"
            "• Private: `t.me/+invite_code` or `t.me/joinchat/...`",
            buttons=cancel_keyboard()
        )
    
    elif data.startswith("vc_qty_"):
        if chat_id not in task_states: 
            return await event.answer("Session expired", alert=True)
        
        qty_type = data.split("_")[2]
        
        if qty_type == "custom":
            task_states[chat_id]['step'] = 'ask_custom_qty'
            await event.edit("🔢 **Custom Amount:**\n\nEnter the number of accounts to use for VC action:", buttons=cancel_keyboard())
        else:
            total_accs = len(vc_clients) if task_states[chat_id].get('type') == 'vc_leave' else len(active_clients)
            if qty_type == "all": 
                count = total_accs
            else: 
                count = int(qty_type)
            if count > total_accs: 
                count = total_accs
            
            await event.delete()
            
            if task_states[chat_id].get('type') == 'vc_leave':
                await execute_vc_leave_task(event, count)
            else:
                channel_input = task_states[chat_id].get('channel_input', '')
                await execute_vc_join_task(event, channel_input, count)
            
            del task_states[chat_id]
    
    elif data.startswith("views_"):
        if chat_id not in task_states:
            return await event.answer("Session expired", alert=True)
        
        qty_type = data.split("_")[1]
        
        if qty_type == "custom":
            task_states[chat_id]['step'] = 'ask_custom_views'
            await event.edit("🔢 **Custom Views Amount:**\n\nEnter the number of views to add per account:", buttons=cancel_keyboard())
        else:
            views_amount = int(qty_type)
            task_states[chat_id]['views_amount'] = views_amount
            task_states[chat_id]['step'] = 'ask_views_quantity'
            await event.edit(
                f"👁️ **Configure Views Task**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📌 **Views per Account:** `{views_amount}`\n\n"
                f"Now select how many accounts to use:",
                buttons=quantity_keyboard()
            )
    
    elif data.startswith("qty_"):
        if chat_id not in task_states: 
            return await event.answer("Session expired", alert=True)
        
        qty_type = data.split("_")[1]
        st_type = task_states[chat_id].get('type')
        
        if qty_type == "custom":
            if st_type == 'views_add':
                task_states[chat_id]['step'] = 'ask_custom_accounts'
                await event.edit("🔢 **Custom Account Amount:**\n\nEnter the number of accounts to use:", buttons=cancel_keyboard())
            else:
                task_states[chat_id]['step'] = 'ask_qty_custom'
                await event.edit("🔢 **Custom Amount:**\n\nEnter the number of accounts to use:", buttons=cancel_keyboard())
        else:
            total_accs = len(active_clients)
            if qty_type == "all": 
                count = total_accs
            else: 
                count = int(qty_type)
            if count > total_accs: 
                count = total_accs
            
            await event.delete()
            
            if st_type == 'join':
                await execute_join_task(event, task_states[chat_id], count)
            elif st_type == 'views_add':
                channel_input = task_states[chat_id].get('channel_input', '')
                message_id = task_states[chat_id].get('message_id', 0)
                views_amount = task_states[chat_id].get('views_amount', 100)
                await execute_post_views_task(event, channel_input, message_id, views_amount, count)
            
            del task_states[chat_id]

    elif data == "show_history":
        logs = get_recent_history()
        log_text = "\n".join(logs) if logs else "No recent activity."
        await event.edit(f"📜 **Recent Activity Log:**\n\n{log_text}", buttons=[[Button.inline("🔙 Back", b"cancel")]])
    
    elif data == "list_accs":
        if not active_clients:
            msg = "❌ No active sessions found."
        else:
            msg = "\n".join([f"👤 `{p}`" for p in active_clients.keys()])
        await event.edit(f"📋 **Active Accounts List:**\n━━━━━━━━━━━━━━━━━━\n{msg}", buttons=[[Button.inline("🔙 Back", b"cancel")]])

    elif data == "add_phone":
        task_states[chat_id] = {'type': 'login', 'step': 'ask_phone'}
        await event.edit("📱 **Login via Phone**\n\nPlease send the phone number with country code:\nExample: `+1234567890`", buttons=cancel_keyboard())
    
    elif data == "add_string":
        task_states[chat_id] = {'type': 'login', 'step': 'ask_string'}
        await event.edit("🧵 **Login via Session String**\n\nPlease send the Pyrogram/Telethon string session:", buttons=cancel_keyboard())

    elif data == "start_join":
        if not active_clients: return await event.answer("❌ No accounts loaded!", alert=True)
        task_states[chat_id] = {'type': 'join', 'step': 'ask_link'}
        await event.edit("🔗 **Step 1:** Send the Channel/Group Link:", buttons=cancel_keyboard())
    
    elif data == "leave_specific":
        if not active_clients: return await event.answer("No accounts!", alert=True)
        task_states[chat_id] = {'type': 'leave_specific', 'step': 'ask_link'}
        await event.edit("📤 **Specific Leave:**\n\nSend the Link of the channel to leave:", buttons=cancel_keyboard())
        
    elif data == "leave_all_confirm":
        if not active_clients: return await event.answer("No accounts!", alert=True)
        await event.edit(
            "⚠️ **DANGER ZONE** ⚠️\n\n"
            "This will force **ALL** connected accounts to leave **ALL** channels and groups.\n"
            "Are you absolutely sure?", 
            buttons=confirm_leave_all_keyboard()
        )
        
    elif data == "exec_leave_all":
        await event.edit("🚀 Processing Mass Leave...", buttons=None)
        await execute_leave_all_channels(event)

    elif data == "menu_manage":
        if not active_clients:
            return await event.answer("❌ No accounts to manage!", alert=True)
        buttons = [[Button.inline(f"🗑 Delete: {p}", f"delete_{p}")] for p in active_clients]
        buttons.append([Button.inline("🔙 Back", b"cancel")])
        await event.edit("⚙️ **Management Console**\n\nSelect an account to remove from database:", buttons=buttons)
        
    elif data.startswith("delete_"):
        phone = data.split("_")[1]
        if phone in active_clients:
            await active_clients[phone].disconnect()
            del active_clients[phone]
        if phone in vc_clients:
            del vc_clients[phone]
        await delete_session(phone)
        await event.answer("Account Deleted!", alert=True)
        await event.edit("✅ Account removed successfully.", buttons=main_menu_keyboard())

@bot.on(events.NewMessage)
async def message_handler(event):
    if not is_user_admin(event.sender_id): return
    
    chat_id = event.chat_id
    text = event.raw_text.strip()
    
    if chat_id not in task_states: return

    state = task_states[chat_id]
    st_type = state.get('type')
    step = state.get('step')

    # --- ADD ADMIN FLOW ---
    if st_type == 'add_admin':
        if step == 'ask_id':
            if not text.isdigit():
                return await event.respond("❌ **Invalid ID.** Please send a numeric User ID.")
            
            new_id = int(text)
            if new_id in get_admin_cache() or new_id in ADMIN_IDS:
                return await event.respond("⚠️ **User is already an Admin.**", buttons=admin_menu_keyboard())
            
            if await add_admin_db(new_id):
                del task_states[chat_id]
                await event.respond(f"✅ **Success!**\nUser `{new_id}` is now an Admin.", buttons=admin_menu_keyboard())
            else:
                await event.respond("❌ **Database Error.**", buttons=admin_menu_keyboard())

    # --- LOGIN FLOW ---
    elif st_type == 'login':
        try:
            if step == 'ask_string':
                # Attempt string login
                try:
                    client = TelegramClient(StringSession(text), API_ID, API_HASH)
                    await client.connect()
                    me = await client.get_me()
                    if not me: raise Exception("Invalid String")
                    
                    phone = f"+{me.phone}" if me.phone else f"ID_{me.id}"
                    await add_session(phone, client.session.save())
                    active_clients[phone] = client
                    asyncio.create_task(keep_online(client))
                    del task_states[chat_id]
                    await event.respond(f"✅ **Success!**\nAdded: `{phone}`", buttons=main_menu_keyboard())
                except Exception:
                    await event.respond("❌ **Invalid String Session.** Try again or Cancel.", buttons=cancel_keyboard())

            elif step == 'ask_phone':
                phone = text.replace(" ", "")
                client = TelegramClient(StringSession(), API_ID, API_HASH)
                await client.connect()
                try:
                    send_c = await client.send_code_request(phone)
                    state.update({'client': client, 'phone': phone, 'hash': send_c.phone_code_hash, 'step': 'ask_otp'})
                    await event.respond(f"📩 **OTP Sent!**\n\nEnter the code received on `{phone}`:\nFormat: `12345`", buttons=cancel_keyboard())
                except Exception as e:
                    await event.respond(f"❌ **Error:** {e}", buttons=cancel_keyboard())

            elif step == 'ask_otp':
                try:
                    code = text.replace(" ", "")
                    await state['client'].sign_in(phone=state['phone'], code=code, phone_code_hash=state['hash'])
                    
                    await add_session(state['phone'], state['client'].session.save())
                    active_clients[state['phone']] = state['client']
                    asyncio.create_task(keep_online(state['client']))
                    del task_states[chat_id]
                    await event.respond("✅ **Login Successful!**", buttons=main_menu_keyboard())
                except SessionPasswordNeededError:
                    state['step'] = 'ask_2fa'
                    await event.respond("🔐 **Two-Step Verification Required**\n\nPlease enter your password:", buttons=cancel_keyboard())
                except Exception as e:
                    await event.respond(f"❌ **Login Failed:** {e}", buttons=cancel_keyboard())

            elif step == 'ask_2fa':
                try:
                    await state['client'].sign_in(password=text)
                    await add_session(state['phone'], state['client'].session.save())
                    active_clients[state['phone']] = state['client']
                    asyncio.create_task(keep_online(state['client']))
                    del task_states[chat_id]
                    await event.respond("✅ **Login Successful!**", buttons=main_menu_keyboard())
                except Exception as e:
                    await event.respond(f"❌ **Password Error:** {e}", buttons=cancel_keyboard())
                
        except Exception as e:
            await event.respond(f"❌ **Critical Error:** {e}", buttons=cancel_keyboard())

    # --- JOIN FLOW ---
    elif st_type == 'join':
        if step == 'ask_link':
            l_type, target = parse_join_target(text)
            if not l_type: return await event.respond("❌ **Invalid Link!** Send again.", buttons=cancel_keyboard())
            state.update({'link_type': l_type, 'target': target, 'display_link': text, 'step': 'ask_delay'})
            await event.respond("⏱ **Set Delay:**\n\nEnter delay in seconds (e.g., `10` or `30`):", buttons=cancel_keyboard())
            
        elif step == 'ask_delay':
            if not text.isdigit(): return await event.respond("⚠️ **Numbers only.** Try again.")
            state['delay'] = int(text)
            state['step'] = 'ask_qty'
            await event.respond("👥 **Quantity Selection:**\n\nHow many accounts should join?", buttons=quantity_keyboard())
            
        elif step == 'ask_qty_custom':
            if not text.isdigit(): return await event.respond("⚠️ **Numbers only.** Try again.")
            count = int(text)
            total = len(active_clients)
            if count > total: count = total
            
            await execute_join_task(event, state, count)
            del task_states[chat_id]

    # --- VC JOIN FLOW ---
    elif st_type == 'vc_join':
        if step == 'ask_channel':
            # Check if it's a valid channel input
            try:
                # Try to get entity with first client
                first_client = list(active_clients.values())[0]
                await get_channel_entity(first_client, text)
                state['channel_input'] = text
                state['step'] = 'ask_vc_quantity'
                await event.respond(
                    f"🎵 **Channel Selected:** `{text}`\n\n"
                    f"Now select how many accounts to join VC:",
                    buttons=vc_quantity_keyboard()
                )
            except Exception as e:
                await event.respond(f"❌ **Invalid channel:** {e}\n\nPlease send a valid channel username or link.", buttons=cancel_keyboard())
        
        elif step == 'ask_custom_qty':
            if not text.isdigit():
                return await event.respond("⚠️ **Numbers only.** Try again.")
            
            count = int(text)
            total = len(active_clients)
            if count > total: count = total
            
            await event.delete()
            await execute_vc_join_task(event, state['channel_input'], count)
            del task_states[chat_id]

    # --- VC LEAVE FLOW ---
    elif st_type == 'vc_leave':
        if step == 'ask_custom_qty':
            if not text.isdigit():
                return await event.respond("⚠️ **Numbers only.** Try again.")
            
            count = int(text)
            total = len(vc_clients)
            if count > total: count = total
            
            await event.delete()
            await execute_vc_leave_task(event, count)
            del task_states[chat_id]

    # --- VIEWS ADD FLOW ---
    elif st_type == 'views_add':
        if step == 'ask_channel':
            # Check if it's a valid channel input
            try:
                first_client = list(active_clients.values())[0]
                await get_channel_entity(first_client, text)
                state['channel_input'] = text
                state['step'] = 'ask_post_id'
                await event.respond(
                    f"📢 **Channel Selected:** `{text}`\n\n"
                    f"Now send the **Post ID** or **Message ID** of the post to boost:\n"
                    f"ℹ️ You can find it in the post link: `t.me/channel/123`\n"
                    f"Example: `123`",
                    buttons=cancel_keyboard()
                )
            except Exception as e:
                await event.respond(f"❌ **Invalid channel:** {e}\n\nPlease send a valid channel username or link.", buttons=cancel_keyboard())
        
        elif step == 'ask_post_id':
            if not text.isdigit():
                return await event.respond("❌ **Invalid Post ID.** Please send a numeric message ID.", buttons=cancel_keyboard())
            
            state['message_id'] = int(text)
            state['step'] = 'ask_views_amount'
            await event.respond(
                f"📝 **Post ID:** `{text}`\n\n"
                f"Select how many views to add **per account**:",
                buttons=views_quantity_keyboard()
            )
        
        elif step == 'ask_custom_views':
            if not text.isdigit():
                return await event.respond("❌ **Invalid amount.** Please send a number.", buttons=cancel_keyboard())
            
            views_amount = int(text)
            if views_amount < 1:
                return await event.respond("❌ **Amount must be at least 1.**", buttons=cancel_keyboard())
            
            state['views_amount'] = views_amount
            state['step'] = 'ask_views_quantity'
            await event.edit(
                f"👁️ **Configure Views Task**\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📌 **Views per Account:** `{views_amount}`\n\n"
                f"Now select how many accounts to use:",
                buttons=quantity_keyboard()
            )
        
        elif step == 'ask_custom_accounts':
            if not text.isdigit():
                return await event.respond("❌ **Invalid amount.** Please send a number.", buttons=cancel_keyboard())
            
            count = int(text)
            total = len(active_clients)
            if count > total: count = total
            
            await event.delete()
            await execute_post_views_task(
                event, 
                state['channel_input'], 
                state['message_id'], 
                state['views_amount'], 
                count
            )
            del task_states[chat_id]

    # --- LEAVE SPECIFIC FLOW ---
    elif st_type == 'leave_specific':
        if step == 'ask_link':
            await execute_leave_specific(event, text)
            del task_states[chat_id]

async def main():
    print("--- 🛡️ Phxm Bot Pro V2 (Full Features) Initializing ---")
    
    # Load admins into cache
    await refresh_admin_cache()
    print(f"✅ Loaded {len(get_admin_cache())} DB admins.")

    # Load saved sessions
    await start_saved_clients()
    print(f"✅ Bot Started. Active Accounts: {len(active_clients)}")
    print("✅ Waiting for commands...")
    
    await bot.start(bot_token=BOT_TOKEN)
    await bot.run_until_disconnected()

if __name__ == '__main__':
    asyncio.run(main())