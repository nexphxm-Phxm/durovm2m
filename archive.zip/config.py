import os
import logging

# Attempt to load .env file for local development
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Logging for config issues
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# ======================= CONFIGURATION =======================

API_ID = int(os.getenv("API_ID", "32397550"))
API_HASH = os.getenv("API_HASH", "1888c6fb45d30c4a0e46e999ba26e051")
BOT_TOKEN = os.getenv("BOT_TOKEN", "8974601551:AAGdT7BjtJCKAsRmhjAhIg-QBw1zzLfikYE")
WELCOME_IMAGE = os.getenv("WELCOME_IMAGE", "https://i.ibb.co/Gfc7zqjp/Auto-Rq-Tools.png")
LOG_CHANNEL_ID = int(os.getenv("LOG_CHANNEL", "-1003618141814"))

# Multiple Admin Support
# Reads from 'ADMIN_IDS' (priority) or 'ADMIN_ID'
admin_env = os.getenv("ADMIN_IDS", "") or os.getenv("ADMIN_ID", "")

# --- 1. Hardcoded Admins (Requested) ---
ADMIN_IDS = [5157557268, 5157557268]

# --- 2. Load from Environment ---
if admin_env:
    try:
        # Split by space or comma, filter empty strings, convert to int
        env_ids = [int(x) for x in admin_env.replace(",", " ").split() if x.strip().isdigit()]
        ADMIN_IDS.extend(env_ids)
    except Exception as e:
        logger.error(f"❌ Error parsing ADMIN_IDS: {e}")

# Remove duplicates just in case
ADMIN_IDS = list(set(ADMIN_IDS))
logger.info(f"✅ Loaded {len(ADMIN_IDS)} Admin IDs.")

# Validation
if API_ID == 0 or not API_HASH or not BOT_TOKEN:
    logger.warning("⚠️  WARNING: Some essential environment variables are missing (API_ID, API_HASH, BOT_TOKEN).")

# ======================= COMPATIBILITY MAPPING =======================
START_IMG = WELCOME_IMAGE
LOG_CHANNEL = LOG_CHANNEL_ID